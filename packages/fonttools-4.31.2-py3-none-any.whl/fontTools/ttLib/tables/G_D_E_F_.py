from .otBase import BaseTTXConverter


class table_G_D_E_F_(BaseTTXConverter):
	pass
